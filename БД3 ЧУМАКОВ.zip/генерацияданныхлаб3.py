import random
from datetime import datetime, timedelta
import csv

# Данные для генерации
departments = [
    (1, 'IT отдел', 'Отдел информационных технологий'),
    (2, 'Отдел кадров', 'Отдел по работе с персоналом'),
    (3, 'Бухгалтерия', 'Финансовый отдел'),
    (4, 'Маркетинг', 'Отдел маркетинга и рекламы'),
    (5, 'Продажи', 'Отдел продаж'),
    (6, 'Производство', 'Производственный отдел'),
    (7, 'Логистика', 'Отдел логистики'),
    (8, 'Юридический', 'Юридический отдел'),
    (9, 'Разработка', 'Отдел разработки ПО'),
    (10, 'Тестирование', 'Отдел тестирования')
]

ticket_priorities = [
    (1, 'Низкий'),
    (2, 'Средний'),
    (3, 'Высокий'),
    (4, 'Критический')
]

ticket_statuses = [
    (1, 'Открыт'),
    (2, 'В работе'),
    (3, 'Решен'),
    (4, 'Закрыт')
]

# Списки для генерации ФИО
first_names_male = ['Александр', 'Алексей', 'Андрей', 'Артем', 'Борис', 'Вадим', 'Василий', 'Виктор', 'Владимир', 
                   'Геннадий', 'Денис', 'Дмитрий', 'Евгений', 'Иван', 'Игорь', 'Кирилл', 'Константин', 'Максим',
                   'Михаил', 'Никита', 'Николай', 'Олег', 'Павел', 'Петр', 'Роман', 'Сергей', 'Станислав', 'Юрий']

first_names_female = ['Алена', 'Алина', 'Анастасия', 'Анна', 'Валентина', 'Валерия', 'Вера', 'Виктория', 'Галина',
                     'Дарья', 'Евгения', 'Екатерина', 'Елена', 'Ирина', 'Ксения', 'Лариса', 'Любовь', 'Людмила',
                     'Марина', 'Мария', 'Надежда', 'Наталья', 'Оксана', 'Ольга', 'Светлана', 'Татьяна', 'Юлия']

last_names = ['Иванов', 'Петров', 'Сидоров', 'Кузнецов', 'Смирнов', 'Попов', 'Васильев', 'Новиков', 'Федоров',
             'Морозов', 'Волков', 'Алексеев', 'Лебедев', 'Семенов', 'Егоров', 'Павлов', 'Козлов', 'Орлов',
             'Николаев', 'Захаров', 'Зайцев', 'Соловьев', 'Борисов', 'Яковлев', 'Григорьев', 'Романов', 'Воробьев']

middle_names_male = ['Александрович', 'Алексеевич', 'Андреевич', 'Артемович', 'Борисович', 'Вадимович', 'Васильевич',
                    'Викторович', 'Владимирович', 'Геннадьевич', 'Денисович', 'Дмитриевич', 'Евгеньевич', 'Иванович']

middle_names_female = ['Александровна', 'Алексеевна', 'Андреевна', 'Артемовна', 'Борисовна', 'Вадимовна', 'Васильевна',
                      'Викторовна', 'Владимировна', 'Геннадьевна', 'Денисовна', 'Дмитриевна', 'Евгеньевна', 'Ивановна']

# Тематики заявок
ticket_subjects = [
    'Проблема с принтером', 'Установка ПО', 'Доступ к сети', 'Зависает компьютер', 'Настройка почты',
    'Обновление системы', 'Проблема с оборудованием', 'Установка антивируса', 'Настройка VPN', 
    'Замена картриджа', 'Восстановление файлов', 'Проблема с монитором', 'Настройка сканера',
    'Установка 1С', 'Проблема с интернетом', 'Резервное копирование', 'Замена клавиатуры',
    'Настройка доступа', 'Установка графического редактора', 'Проблема с аудио',
    'Обновление драйверов', 'Настройка телефона', 'Проблема с проектором', 'Восстановление пароля',
    'Установка среды разработки', 'Проблема с веб-камерой', 'Настройка фаервола',
    'Установка CAD системы', 'Проблема с ИБП', 'Настройка биометрии'
]

ticket_descriptions = [
    'Не печатает сетевой принтер', 'Требуется установка программного обеспечения', 
    'Нет подключения к корпоративной сети', 'Компьютер тормозит при работе', 
    'Не работает почтовый клиент', 'Требуется обновление ОС', 'Не работает USB устройство',
    'Требуется установка антивирусной программы', 'Не подключается к VPN', 
    'Требуется замена картриджа в принтере', 'Удалены важные документы', 
    'Мерцает экран монитора', 'Сканер не распознает документы', 'Требуется установка 1С',
    'Медленно работает интернет', 'Настройка автоматического бэкапа', 'Сломалась клавиатура',
    'Нет доступа к общей папке', 'Требуется графический редактор', 'Не работают колонки',
    'Требуется обновление драйверов', 'Настройка IP-телефона', 'Не включается проектор',
    'Забыт пароль от учетной записи', 'Требуется среда разработки', 'Не работает веб-камера',
    'Блокируется нужный сайт', 'Требуется система проектирования', 'Не работает источник питания',
    'Не работает сканер отпечатков'
]

comments = [
    'Проверил оборудование, проблема решена', 'Установил необходимое ПО', 'Сбросил настройки сети',
    'Произвел очистку системы', 'Настроил почтовый клиент', 'Запустил обновление системы',
    'Заменил неисправное оборудование', 'Установил антивирус', 'Настроил VPN подключение',
    'Заменил картридж', 'Восстановил файлы из резервной копии', 'Подключил запасное оборудование',
    'Настроил драйвер устройства', 'Установил требуемое ПО', 'Проверил подключение к интернету',
    'Настроил резервное копирование', 'Заменил периферийное устройство', 'Настроил права доступа',
    'Установил графический редактор', 'Проверил аудио систему', 'Обновил драйверы',
    'Настроил телефонную систему', 'Заменил лампу в проекторе', 'Сбросил пароль',
    'Установил среду разработки', 'Настроил веб-камеру', 'Добавил в исключения фаервола',
    'Установил систему проектирования', 'Заменил батарею ИБП', 'Настроил биометрическую систему'
]

def generate_fio():
    gender = random.choice(['male', 'female'])
    if gender == 'male':
        first_name = random.choice(first_names_male)
        middle_name = random.choice(middle_names_male)
    else:
        first_name = random.choice(first_names_female)
        middle_name = random.choice(middle_names_female)
    
    last_name = random.choice(last_names)
    if gender == 'female':
        last_name += 'а'
    
    return f"{last_name} {first_name[0]}.{middle_name[0]}."

def generate_phone():
    return f"+7-9{random.randint(10, 99)}-{random.randint(100, 999)}-{random.randint(10, 99)}-{random.randint(10, 99)}"

def generate_email(fio, domain="company.com"):
    name_parts = fio.split()
    last_name = name_parts[0].lower()
    initials = name_parts[1].replace('.', '').lower()
    return f"{last_name}.{initials}@{domain}"

def generate_date(start_date="2024-01-01", end_date="2024-12-31"):
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")
    random_date = start + timedelta(days=random.randint(0, (end - start).days))
    return random_date.strftime("%Y-%m-%d")

def generate_support_staff(count=20):
    staff = []
    for i in range(1, count + 1):
        fio = generate_fio()
        email = generate_email(fio)
        phone = generate_phone()
        staff.append((i, fio, email, phone))
    return staff

def generate_users(count=200):
    users = []
    for i in range(1, count + 1):
        fio = generate_fio()
        phone = generate_phone()
        email = generate_email(fio)
        department_id = random.randint(1, len(departments))
        users.append((i, fio, phone, email, department_id))
    return users

def generate_tickets(count=1000):
    tickets = []
    for i in range(1, count + 1):
        subject = random.choice(ticket_subjects)
        description = random.choice(ticket_descriptions)
        create_date = generate_date()
        user_id = random.randint(1, 200)  # 200 пользователей
        status_id = random.choices([1, 2, 3, 4], weights=[0.2, 0.3, 0.3, 0.2])[0]
        staff_id = random.randint(1, 20)  # 20 сотрудников поддержки
        priority_id = random.choices([1, 2, 3, 4], weights=[0.3, 0.4, 0.2, 0.1])[0]
        tickets.append((i, subject, description, create_date, user_id, status_id, staff_id, priority_id))
    return tickets

def generate_ticket_comments(count=1500):
    comments_list = []
    for i in range(1, count + 1):
        comment_text = random.choice(comments)
        # Комментарий должен быть после создания заявки
        ticket_id = random.randint(1, 1000)
        comment_date = generate_date("2024-01-02", "2024-12-31")
        comments_list.append((i, comment_text, comment_date, ticket_id))
    return comments_list

def save_to_sql(filename="generated_data.sql"):
    with open(filename, 'w', encoding='utf-8') as f:
        # Departments
        f.write("-- Departments\n")
        for dept in departments:
            f.write(f"INSERT INTO departments VALUES {dept};\n")
        
        # Ticket Priority
        f.write("\n-- Ticket Priority\n")
        for priority in ticket_priorities:
            f.write(f"INSERT INTO ticket_priority VALUES {priority};\n")
        
        # Ticket Status
        f.write("\n-- Ticket Status\n")
        for status in ticket_statuses:
            f.write(f"INSERT INTO ticket_status VALUES {status};\n")
        
        # Support Staff
        f.write("\n-- Support Staff\n")
        staff = generate_support_staff(20)
        for s in staff:
            f.write(f"INSERT INTO support_staff VALUES {s};\n")
        
        # Users
        f.write("\n-- Users\n")
        users = generate_users(200)
        for u in users:
            f.write(f"INSERT INTO users VALUES {u};\n")
        
        # Tickets
        f.write("\n-- Tickets\n")
        tickets = generate_tickets(1000)
        for t in tickets:
            f.write(f"INSERT INTO tickets VALUES {t};\n")
        
        # Ticket Comments
        f.write("\n-- Ticket Comments\n")
        comments = generate_ticket_comments(1500)
        for c in comments:
            f.write(f"INSERT INTO ticket_comments VALUES {c};\n")

def save_to_csv():
    # Сохранение в CSV файлы для каждой таблицы
    staff = generate_support_staff(20)
    with open('support_staff.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['support_staff_id', 'support_staff_fio', 'support_staff_email', 'support_staff_phone'])
        writer.writerows(staff)
    
    users = generate_users(200)
    with open('users.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['user_id', 'user_fio', 'user_phone', 'user_email', 'departments_department_id'])
        writer.writerows(users)
    
    tickets = generate_tickets(1000)
    with open('tickets.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['ticket_id', 'ticket_subject', 'ticket_description', 'ticket_data_create', 
                        'users_user_id', 'ticket_status_ticket_status_id', 'support_staff_support_staff_id', 'ticket_priority_id'])
        writer.writerows(tickets)
    
    comments = generate_ticket_comments(1500)
    with open('ticket_comments.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['ticket_comment_id', 'ticket_comment_text', 'ticket_comment_date', 'tickets_ticket_id'])
        writer.writerows(comments)

if __name__ == "__main__":
    print("Генерация данных...")
    
    # Генерация SQL файла
    save_to_sql("generated_database.sql")
    print("SQL файл создан: generated_database.sql")
    
    # Генерация CSV файлов
    save_to_csv()
    print("CSV файлы созданы: support_staff.csv, users.csv, tickets.csv, ticket_comments.csv")
    
    # Статистика
    print(f"\nСгенерировано данных:")
    print(f"- Отделы: {len(departments)}")
    print(f"- Приоритеты: {len(ticket_priorities)}")
    print(f"- Статусы: {len(ticket_statuses)}")
    print(f"- Сотрудники поддержки: 20")
    print(f"- Пользователи: 200")
    print(f"- Заявки: 1000")
    print(f"- Комментарии: 1500")
    print(f"Всего записей: {len(departments) + len(ticket_priorities) + len(ticket_statuses) + 20 + 200 + 1000 + 1500}")