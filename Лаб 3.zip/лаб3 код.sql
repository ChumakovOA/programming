USE mgpu_ico_db_20;
CREATE TABLE departments (
    department_id           INTEGER NOT NULL,  -- Исправлено: depatment_id -> department_id
    department_name        VARCHAR(50) NOT NULL,
    department_description VARCHAR(200)
);

ALTER TABLE departments ADD CONSTRAINT departments_pk PRIMARY KEY ( department_id );  -- Исправлено здесь тоже

CREATE TABLE support_staff (
    support_staff_id      INTEGER NOT NULL,
    support_staff_fio     VARCHAR(30) NOT NULL,
    support_staff_email   VARCHAR(100) NOT NULL,
    support_staff_phone   VARCHAR(50) NOT NULL
);

ALTER TABLE support_staff ADD CONSTRAINT support_staff_pk PRIMARY KEY ( support_staff_id );

CREATE TABLE ticket_comments (
    ticket_comment_id    INTEGER NOT NULL,  -- Исправлено: ticket_cooment_id -> ticket_comment_id
    ticket_comment_text VARCHAR(1000) NOT NULL,
    ticket_comment_date DATE NOT NULL,
    tickets_ticket_id   INTEGER NOT NULL
);

ALTER TABLE ticket_comments ADD CONSTRAINT ticket_comments_pk PRIMARY KEY ( ticket_comment_id );  -- Исправлено здесь тоже

CREATE TABLE ticket_priority (
    ticket_priority_id  INTEGER NOT NULL,  -- Исправлено: ticket_priorirty_id -> ticket_priority_id
    ticket_priority_name VARCHAR(50) NOT NULL
);

ALTER TABLE ticket_priority ADD CONSTRAINT ticket_priority_pk PRIMARY KEY ( ticket_priority_id );  -- Исправлено здесь тоже

CREATE TABLE ticket_status (
    ticket_status_id   INTEGER NOT NULL,
    ticket_status_name VARCHAR(50) NOT NULL
);

ALTER TABLE ticket_status ADD CONSTRAINT ticket_status_pk PRIMARY KEY ( ticket_status_id );

CREATE TABLE tickets (
    ticket_id                      INTEGER NOT NULL,
    ticket_subject                 VARCHAR(100) NOT NULL,
    ticket_description             VARCHAR(100) NOT NULL,
    ticket_data_create             DATE NOT NULL,
    users_user_id                  INTEGER NOT NULL,
    ticket_status_ticket_status_id INTEGER NOT NULL,
    support_staff_support_staff_id INTEGER NOT NULL,
    ticket_priority_id             INTEGER NOT NULL  -- Укорочено имя столбца
);

ALTER TABLE tickets ADD CONSTRAINT tickets_pk PRIMARY KEY ( ticket_id );

CREATE TABLE users (
    user_id                  INTEGER NOT NULL,
    user_fio                 VARCHAR(500) NOT NULL,
    user_phone               VARCHAR(50) NOT NULL,
    user_email               VARCHAR(100),
    departments_department_id INTEGER NOT NULL  
);

ALTER TABLE users ADD CONSTRAINT users_pk PRIMARY KEY ( user_id );

ALTER TABLE ticket_comments
    ADD CONSTRAINT ticket_comments_tickets_fk FOREIGN KEY ( tickets_ticket_id )
        REFERENCES tickets ( ticket_id );

ALTER TABLE tickets
    ADD CONSTRAINT tickets_support_staff_fk FOREIGN KEY ( support_staff_support_staff_id )
        REFERENCES support_staff ( support_staff_id );

ALTER TABLE tickets
    ADD CONSTRAINT tickets_ticket_priority_fk FOREIGN KEY ( ticket_priority_id )  
        REFERENCES ticket_priority ( ticket_priority_id );  

ALTER TABLE tickets
    ADD CONSTRAINT tickets_ticket_status_fk FOREIGN KEY ( ticket_status_ticket_status_id )
        REFERENCES ticket_status ( ticket_status_id );

ALTER TABLE tickets
    ADD CONSTRAINT tickets_users_fk FOREIGN KEY ( users_user_id )
        REFERENCES users ( user_id );

ALTER TABLE users
    ADD CONSTRAINT users_departments_fk FOREIGN KEY ( departments_department_id )  
        REFERENCES departments ( department_id );  

-- Заполнение таблицы departments
INSERT INTO departments (department_id, department_name, department_description) VALUES 
(1, 'IT отдел', 'Отдел информационных технологий и технической поддержки'),
(2, 'Отдел кадров', 'Отдел по работе с персоналом и кадровому делопроизводству'),
(3, 'Бухгалтерия', 'Финансовый отдел и бухгалтерский учет'),
(4, 'Маркетинг', 'Отдел маркетинга и рекламы'),
(5, 'Продажи', 'Отдел продаж и работы с клиентами'),
(6, 'Разработка', 'Отдел разработки программного обеспечения'),
(7, 'Тестирование', 'Отдел контроля качества и тестирования'),
(8, 'Аналитика', 'Отдел бизнес-аналитики и исследований'),
(9, 'Юридический', 'Юридический отдел и правовое сопровождение'),
(10, 'Логистика', 'Отдел логистики и снабжения');

-- Заполнение таблицы ticket_priority
INSERT INTO ticket_priority (ticket_priority_id, ticket_priority_name) VALUES 
(1, 'Низкий'),
(2, 'Средний'),
(3, 'Высокий'),
(4, 'Критический');

-- Заполнение таблицы ticket_status
INSERT INTO ticket_status (ticket_status_id, ticket_status_name) VALUES 
(1, 'Открыт'),
(2, 'В работе'),
(3, 'Ожидание ответа'),
(4, 'Решен'),
(5, 'Закрыт');

INSERT INTO support_staff (support_staff_id, support_staff_fio, support_staff_email, support_staff_phone) VALUES 
(1, 'Петров С.С.', 'i.petrov@company.com', '+7-900-111-11-11'),
(2, 'Иванова М.П.', 'm.ivanova@company.com', '+7-900-111-11-12'),
(3, 'Сидоров С.В.', 's.sidorov@company.com', '+7-900-111-11-13'),
(4, 'Кузнецова О.Д.', 'o.kuznetsova@company.com', '+7-900-111-11-14'),
(5, 'Смирнов А.Н.', 'a.smirnov@company.com', '+7-900-111-11-15'),
(6, 'Попова Е.В.', 'e.popova@company.com', '+7-900-111-11-16'),
(7, 'Петров С.С.', 'd.vasiliev@company.com', '+7-900-111-11-17'),
(8, 'Новикова Н.И.', 'n.novikova@company.com', '+7-900-111-11-18'),
(9, 'Федоров А.М.', 'a.fedorov@company.com', '+7-900-111-11-19'),
(10, 'Морозова Т.С.', 't.morozova@company.com', '+7-900-111-11-20'),
(11, 'Волков П.А.', 'p.volkov@company.com', '+7-900-111-11-21'),
(12, 'Алексеева С.В.', 's.alekseeva@company.com', '+7-900-111-11-22'),
(13, 'Лебедев К.Д.', 'k.lebedev@company.com', '+7-900-111-11-23'),
(14, 'Семенова Л.Г.', 'l.semenova@company.com', '+7-900-111-11-24'),
(15, 'Егоров Р.Ф.', 'r.egorov@company.com', '+7-900-111-11-25'),
(16, 'Павлова И.Ц.', 'i.pavlova@company.com', '+7-900-111-11-26'),
(17, 'Козлов А.Ю.', 'a.kozlov@company.com', '+7-900-111-11-27'),
(18, 'Орлова Т.Б.', 't.orlova@company.com', '+7-900-111-11-28'),
(19, 'Николаев В.Е.', 'v.nikolaev@company.com', '+7-900-111-11-29'),
(20, 'Захарова М.Р.', 'm.zakharova@company.com', '+7-900-111-11-30'),
(21, 'Петров С.С.', 'p.zaitsev@company.com', '+7-900-111-11-31'),
(22, 'Соловьева Е.Т.', 'e.solovieva@company.com', '+7-900-111-11-32'),
(23, 'Борисов Г.Я.', 'g.borisov@company.com', '+7-900-111-11-33'),
(24, 'Яковлева А.Ч.', 'a.yakovleva@company.com', '+7-900-111-11-34'),
(25, 'Григорьев М.Ш.', 'm.grigoriev@company.com', '+7-900-111-11-35'),
(26, 'Романова К.Щ.', 'k.romanova@company.com', '+7-900-111-11-36'),
(27, 'Воробьев Д.Э.', 'd.vorobiev@company.com', '+7-900-111-11-37'),
(28, 'Сергеева Л.Ж.', 'l.sergeeva@company.com', '+7-900-111-11-38'),
(29, 'Кузьмин В.З.', 'v.kuzmin@company.com', '+7-900-111-11-39'),
(30, 'Фролова Н.Х.', 'n.frolova@company.com', '+7-900-111-11-40'),
(31, 'Александров С.В.', 's.aleksandrov@company.com', '+7-900-111-11-41'),
(32, 'Дмитриева О.Н.', 'o.dmitrieva@company.com', '+7-900-111-11-42'),
(33, 'Королев И.М.', 'i.korolev@company.com', '+7-900-111-11-43'),
(34, 'Герасимова Т.К.', 't.gerasimova@company.com', '+7-900-111-11-44'),
(35, 'Тихонов П.Л.', 'p.tikhonov@company.com', '+7-900-111-11-45'),
(36, 'Савченко Е.П.', 'e.savchenko@company.com', '+7-900-111-11-46'),
(37, 'Киселев А.Р.', 'a.kiselev@company.com', '+7-900-111-11-47'),
(38, 'Максимова В.С.', 'v.maksimova@company.com', '+7-900-111-11-48'),
(39, 'Поляков Д.Т.', 'd.polyakov@company.com', '+7-900-111-11-49'),
(40, 'Щербакова И.У.', 'i.shcherbakova@company.com', '+7-900-111-11-50'),
(41, 'Белов М.Ф.', 'm.belov@company.com', '+7-900-111-11-51'),
(42, 'Медведева С.Ц.', 's.medvedeva@company.com', '+7-900-111-11-52'),
(43, 'Антонов К.Ч.', 'k.antonov@company.com', '+7-900-111-11-53'),
(44, 'Маркова Л.Ш.', 'l.markova@company.com', '+7-900-111-11-54'),
(45, 'Львов Р.Щ.', 'r.lvov@company.com', '+7-900-111-11-55'),
(46, 'Владимирова А.Э.', 'a.vladimirova@company.com', '+7-900-111-11-56'),
(47, 'Соколов Н.Ю.', 'n.sokolov@company.com', '+7-900-111-11-57'),
(48, 'Петров С.С.', 'v.panina@company.com', '+7-900-111-11-58'),
(49, 'Жуков Д.В.', 'd.zhukov@company.com', '+7-900-111-11-59'),
(50, 'Петров С.С.', 'e.nikitina@company.com', '+7-900-111-11-60');

-- Заполнение таблицы users
INSERT INTO users (user_id, user_fio, user_phone, user_email, departments_department_id) VALUES 
(1, 'Петров С.С.', '+7-900-222-11-11', 's.petrov@company.com', 1),
(2, 'Иванов А.А.', '+7-900-222-11-12', 'a.ivanov@company.com', 2),
(3, 'Сидорова М.И.', '+7-900-222-11-13', 'm.sidorova@company.com', 3),
(4, 'Кузнецов Д.В.', '+7-900-222-11-14', 'd.kuznetsov@company.com', 4),
(5, 'Смирнова Е.П.', '+7-900-222-11-15', 'e.smirnova@company.com', 5),
(6, 'Попов В.С.', '+7-900-222-11-16', 'v.popov@company.com', 6),
(7, 'Васильева А.К.', '+7-900-222-11-17', 'a.vasilieva@company.com', 7),
(8, 'Новиков И.Л.', '+7-900-222-11-18', 'i.novikov@company.com', 8),
(9, 'Федорова О.М.', '+7-900-222-11-19', 'o.fedorova@company.com', 9),
(10, 'Морозов П.Н.', '+7-900-222-11-20', 'p.morozov@company.com', 10),
(11, 'Волков С.А.', '+7-900-222-11-21', 's.volkov@company.com', 1),
(12, 'Алексеева Н.В.', '+7-900-222-11-22', 'n.alekseeva@company.com', 2),
(13, 'Лебедев К.Д.', '+7-900-222-11-23', 'k.lebedev@company.com', 3),
(14, 'Семенова Л.Г.', '+7-900-222-11-24', 'l.semenova@company.com', 4),
(15, 'Егоров Р.Ф.', '+7-900-222-11-25', 'r.egorov@company.com', 5),
(16, 'Павлова И.Ц.', '+7-900-222-11-26', 'i.pavlova@company.com', 6),
(17, 'Козлов А.Ю.', '+7-900-222-11-27', 'a.kozlov@company.com', 7),
(18, 'Орлова Т.Б.', '+7-900-222-11-28', 't.orlova@company.com', 8),
(19, 'Николаев В.Е.', '+7-900-222-11-29', 'v.nikolaev@company.com', 9),
(20, 'Захарова М.Р.', '+7-900-222-11-30', 'm.zakharova@company.com', 10),
(21, 'Зайцев П.О.', '+7-900-222-11-31', 'p.zaitsev@company.com', 1),
(22, 'Соловьева Е.Т.', '+7-900-222-11-32', 'e.solovieva@company.com', 2),
(23, 'Борисов Г.Я.', '+7-900-222-11-33', 'g.borisov@company.com', 3),
(24, 'Яковлева А.Ч.', '+7-900-222-11-34', 'a.yakovleva@company.com', 4),
(25, 'Григорьев М.Ш.', '+7-900-222-11-35', 'm.grigoriev@company.com', 5),
(26, 'Романова К.Щ.', '+7-900-222-11-36', 'k.romanova@company.com', 6),
(27, 'Воробьев Д.Э.', '+7-900-222-11-37', 'd.vorobiev@company.com', 7),
(28, 'Сергеева Л.Ж.', '+7-900-222-11-38', 'l.sergeeva@company.com', 8),
(29, 'Кузьмин В.З.', '+7-900-222-11-39', 'v.kuzmin@company.com', 9),
(30, 'Фролова Н.Х.', '+7-900-222-11-40', 'n.frolova@company.com', 10),
(31, 'Александров С.В.', '+7-900-222-11-41', 's.aleksandrov@company.com', 1),
(32, 'Дмитриева О.Н.', '+7-900-222-11-42', 'o.dmitrieva@company.com', 2),
(33, 'Королев И.М.', '+7-900-222-11-43', 'i.korolev@company.com', 3),
(34, 'Герасимова Т.К.', '+7-900-222-11-44', 't.gerasimova@company.com', 4),
(35, 'Тихонов П.Л.', '+7-900-222-11-45', 'p.tikhonov@company.com', 5),
(36, 'Савченко Е.П.', '+7-900-222-11-46', 'e.savchenko@company.com', 6),
(37, 'Киселев А.Р.', '+7-900-222-11-47', 'a.kiselev@company.com', 7),
(38, 'Максимова В.С.', '+7-900-222-11-48', 'v.maksimova@company.com', 8),
(39, 'Поляков Д.Т.', '+7-900-222-11-49', 'd.polyakov@company.com', 9),
(40, 'Щербакова И.У.', '+7-900-222-11-50', 'i.shcherbakova@company.com', 10),
(41, 'Белов М.Ф.', '+7-900-222-11-51', 'm.belov@company.com', 1),
(42, 'Медведева С.Ц.', '+7-900-222-11-52', 's.medvedeva@company.com', 2),
(43, 'Антонов К.Ч.', '+7-900-222-11-53', 'k.antonov@company.com', 3),
(44, 'Маркова Л.Ш.', '+7-900-222-11-54', 'l.markova@company.com', 4),
(45, 'Львов Р.Щ.', '+7-900-222-11-55', 'r.lvov@company.com', 5),
(46, 'Владимирова А.Э.', '+7-900-222-11-56', 'a.vladimirova@company.com', 6),
(47, 'Соколов Н.Ю.', '+7-900-222-11-57', 'n.sokolov@company.com', 7),
(48, 'Панина В.Я.', '+7-900-222-11-58', 'v.panina@company.com', 8),
(49, 'Жуков Д.В.', '+7-900-222-11-59', 'd.zhukov@company.com', 9),
(50, 'Никитина Е.С.', '+7-900-222-11-60', 'e.nikitina@company.com', 10);

-- Заполнение таблицы tickets
INSERT INTO tickets (ticket_id, ticket_subject, ticket_description, ticket_data_create, users_user_id, ticket_status_ticket_status_id, support_staff_support_staff_id, ticket_priority_id) VALUES 
(1, 'Проблема с принтером', 'Не печатает цветной принтер в кабинете 301', DATE '2024-01-15', 1, 4, 1, 2),
(2, 'Установка ПО', 'Требуется установка Microsoft Office на новый компьютер', DATE '2024-01-16', 2, 4, 2, 2),
(3, 'Доступ к сети', 'Нет доступа к корпоративной сети Wi-Fi', DATE '2024-01-17', 3, 4, 3, 3),
(4, 'Проблема с почтой', 'Не приходят письма на корпоративную почту', DATE '2024-01-18', 4, 2, 4, 3),
(5, 'Зависает компьютер', 'Компьютер постоянно зависает при работе с 1С', DATE '2024-01-19', 5, 1, 5, 2),
(6, 'Настройка VPN', 'Требуется настройка VPN для удаленной работы', DATE '2024-01-20', 6, 4, 6, 2),
(7, 'Обновление антивируса', 'Антивирус требует обновления баз', DATE '2024-01-21', 7, 4, 7, 1),
(8, 'Проблема с монитором', 'Мерцает экран монитора', DATE '2024-01-22', 8, 3, 8, 2),
(9, 'Восстановление файлов', 'Удалены важные документы, требуется восстановление', DATE '2024-01-23', 9, 2, 9, 4),
(10, 'Замена клавиатуры', 'Сломалась клавиатура, требуется замена', DATE '2024-01-24', 10, 4, 10, 1),
(11, 'Настройка почты на телефоне', 'Не настроена корпоративная почта на смартфоне', DATE '2024-01-25', 11, 4, 1, 2),
(12, 'Проблема с сканером', 'Сканер не распознает документы', DATE '2024-01-26', 12, 1, 2, 2),
(13, 'Обновление Windows', 'Требуется обновление операционной системы', DATE '2024-01-27', 13, 4, 3, 2),
(14, 'Резервное копирование', 'Настройка автоматического резервного копирования', DATE '2024-01-28', 14, 2, 4, 3),
(15, 'Проблема с мышкой', 'Не работает беспроводная мышь', DATE '2024-01-29', 15, 4, 5, 1),
(16, 'Доступ к shared folder', 'Нет доступа к общей папке на сервере', DATE '2024-01-30', 16, 4, 6, 2),
(17, 'Установка 1С', 'Требуется установка и настройка 1С:Предприятие', DATE '2024-01-31', 17, 1, 7, 3),
(18, 'Проблема с интернетом', 'Медленно работает интернет', DATE '2024-02-01', 18, 4, 8, 2),
(19, 'Замена картриджа', 'Требуется замена картриджа в принтере', DATE '2024-02-02', 19, 4, 9, 1),
(20, 'Настройка доступа', 'Настройка прав доступа к базе данных', DATE '2024-02-03', 20, 2, 10, 3),
(21, 'Ремонт компьютера', 'Не включается системный блок', DATE '2024-02-04', 21, 4, 1, 4),
(22, 'Установка Photoshop', 'Требуется установка графического редактора', DATE '2024-02-05', 22, 4, 2, 2),
(23, 'Проблема с веб-камерой', 'Не работает веб-камера на ноутбуке', DATE '2024-02-06', 23, 1, 3, 2),
(24, 'Настройка принтера', 'Добавление сетевого принтера', DATE '2024-02-07', 24, 4, 4, 1),
(25, 'Восстановление пароля', 'Забыт пароль от учетной записи', DATE '2024-02-08', 25, 4, 5, 2),
(26, 'Обновление драйверов', 'Требуется обновление драйверов видеокарты', DATE '2024-02-09', 26, 2, 6, 2),
(27, 'Проблема с колонками', 'Не работают колонки на компьютере', DATE '2024-02-10', 27, 4, 7, 1),
(28, 'Настройка телефона', 'Настройка IP-телефона на рабочем месте', DATE '2024-02-11', 28, 4, 8, 2),
(29, 'Установка антивируса', 'Требуется установка антивирусной программы', DATE '2024-02-12', 29, 1, 9, 2),
(30, 'Проблема с проектором', 'Не включается проектор в переговорной', DATE '2024-02-13', 30, 4, 10, 3),
(31, 'Настройка монитора', 'Неправильное разрешение экрана', DATE '2024-02-14', 31, 4, 1, 1),
(32, 'Установка Excel', 'Требуется установка Microsoft Excel', DATE '2024-02-15', 32, 4, 2, 2),
(33, 'Проблема с наушниками', 'Не работают USB-наушники', DATE '2024-02-16', 33, 1, 3, 1),
(34, 'Настройка почтового клиента', 'Настройка Outlook для работы с почтой', DATE '2024-02-17', 34, 2, 4, 2),
(35, 'Замена блока питания', 'Требуется замена блока питания в компьютере', DATE '2024-02-18', 35, 4, 5, 3),
(36, 'Установка Access', 'Требуется установка Microsoft Access', DATE '2024-02-19', 36, 4, 6, 2),
(37, 'Проблема с микрофоном', 'Не работает микрофон на гарнитуре', DATE '2024-02-20', 37, 1, 7, 2),
(38, 'Настройка роутера', 'Настройка беспроводного роутера', DATE '2024-02-21', 38, 4, 8, 3),
(39, 'Установка Python', 'Требуется установка Python для разработки', DATE '2024-02-22', 39, 4, 9, 2),
(40, 'Проблема с ИБП', 'Не работает источник бесперебойного питания', DATE '2024-02-23', 40, 2, 10, 3),
(41, 'Настройка биометрии', 'Настройка сканера отпечатков пальцев', DATE '2024-02-24', 41, 4, 1, 2),
(42, 'Установка Visual Studio', 'Требуется установка среды разработки', DATE '2024-02-25', 42, 4, 2, 3),
(43, 'Проблема с тачпадом', 'Не работает тачпад на ноутбуке', DATE '2024-02-26', 43, 1, 3, 2),
(44, 'Настройка фаервола', 'Настройка правил файервола', DATE '2024-02-27', 44, 2, 4, 3),
(45, 'Установка AutoCAD', 'Требуется установка системы автоматизированного проектирования', DATE '2024-02-28', 45, 4, 5, 3),
(46, 'Проблема с SSD', 'Медленно работает твердотельный накопитель', DATE '2024-02-29', 46, 4, 6, 2),
(47, 'Настройка RAID', 'Настройка RAID-массива на сервере', DATE '2024-03-01', 47, 1, 7, 4),
(48, 'Установка Java', 'Требуется установка Java Runtime Environment', DATE '2024-03-02', 48, 4, 8, 1),
(49, 'Проблема с кулером', 'Сильно шумит кулер в системном блоке', DATE '2024-03-03', 49, 4, 9, 2),
(50, 'Настройка видеоконференции', 'Настройка системы видеоконференцсвязи', DATE '2024-03-04', 50, 2, 10, 3);

-- Заполнение таблицы ticket_comments
INSERT INTO ticket_comments (ticket_comment_id, ticket_comment_text, ticket_comment_date, tickets_ticket_id) VALUES 
(1, 'Проверил принтер, проблема в картридже. Заменил картридж.', DATE '2024-01-15', 1),
(2, 'Установил Microsoft Office 365. Проверил работу.', DATE '2024-01-16', 2),
(3, 'Сбросил настройки сети. Доступ восстановлен.', DATE '2024-01-17', 3),
(4, 'Проверяю настройки почтового сервера.', DATE '2024-01-18', 4),
(5, 'Заявка принята в работу.', DATE '2024-01-19', 5),
(6, 'Настроил VPN подключение. Протестировал работу.', DATE '2024-01-20', 6),
(7, 'Обновил антивирусные базы. Проверил систему.', DATE '2024-01-21', 7),
(8, 'Ожидаю поставку нового монитора.', DATE '2024-01-22', 8),
(9, 'Восстановил файлы из резервной копии.', DATE '2024-01-23', 9),
(10, 'Заменил клавиатуру на новую.', DATE '2024-01-24', 10),
(11, 'Настроил почту на смартфоне. Проверил отправку и получение.', DATE '2024-01-25', 11),
(12, 'Заявка принята в работу.', DATE '2024-01-26', 12),
(13, 'Обновил Windows до последней версии. Перезагрузил компьютер.', DATE '2024-01-27', 13),
(14, 'Настраиваю автоматическое резервное копирование.', DATE '2024-01-28', 14),
(15, 'Заменил батарейку в мышке. Работает нормально.', DATE '2024-01-29', 15),
(16, 'Настроил права доступа к общей папке.', DATE '2024-01-30', 16),
(17, 'Заявка принята в работу.', DATE '2024-01-31', 17),
(18, 'Проверил скорость интернета. Проблема решена.', DATE '2024-02-01', 18),
(19, 'Заменил картридж в принтере.', DATE '2024-02-02', 19),
(20, 'Настраиваю права доступа к базе данных.', DATE '2024-02-03', 20),
(21, 'Заменил блок питания. Компьютер работает.', DATE '2024-02-04', 21),
(22, 'Установил Adobe Photoshop. Активировал лицензию.', DATE '2024-02-05', 22),
(23, 'Заявка принята в работу.', DATE '2024-02-06', 23),
(24, 'Добавил сетевой принтер в систему.', DATE '2024-02-07', 24),
(25, 'Сбросил пароль. Выдал временный пароль.', DATE '2024-02-08', 25),
(26, 'Обновляю драйверы видеокарты.', DATE '2024-02-09', 26),
(27, 'Проверил подключение колонок. Работают нормально.', DATE '2024-02-10', 27),
(28, 'Настроил IP-телефон. Протестировал звонки.', DATE '2024-02-11', 28),
(29, 'Заявка принята в работу.', DATE '2024-02-12', 29),
(30, 'Заменил лампу в проекторе. Работает.', DATE '2024-02-13', 30),
(31, 'Настроил разрешение экрана 1920x1080.', DATE '2024-02-14', 31),
(32, 'Установил Microsoft Excel. Проверил работу.', DATE '2024-02-15', 32),
(33, 'Заявка принята в работу.', DATE '2024-02-16', 33),
(34, 'Настраиваю Outlook для работы с почтой.', DATE '2024-02-17', 34),
(35, 'Заменил блок питания. Система работает стабильно.', DATE '2024-02-18', 35),
(36, 'Установил Microsoft Access. Проверил базы данных.', DATE '2024-02-19', 36),
(37, 'Заявка принята в работу.', DATE '2024-02-20', 37),
(38, 'Настроил беспроводной роутер. Раздаёт интернет.', DATE '2024-02-21', 38),
(39, 'Установил Python 3.9. Настроил окружение.', DATE '2024-02-22', 39),
(40, 'Диагностирую проблему с ИБП.', DATE '2024-02-23', 40),
(41, 'Настроил сканер отпечатков пальцев. Работает.', DATE '2024-02-24', 41),
(42, 'Установил Visual Studio 2022. Готова к работе.', DATE '2024-02-25', 42),
(43, 'Заявка принята в работу.', DATE '2024-02-26', 43),
(44, 'Настраиваю правила файервола.', DATE '2024-02-27', 44),
(45, 'Установил AutoCAD 2024. Активировал лицензию.', DATE '2024-02-28', 45),
(46, 'Проверил SSD. Произвёл оптимизацию.', DATE '2024-02-29', 46),
(47, 'Заявка принята в работу.', DATE '2024-03-01', 47),
(48, 'Установил Java Runtime Environment. Проверил работу.', DATE '2024-03-02', 48),
(49, 'Почистил кулер от пыли. Шум уменьшился.', DATE '2024-03-03', 49),
(50, 'Настраиваю систему видеоконференцсвязи.', DATE '2024-03-04', 50);

DROP TABLE IF EXISTS ticket_comments;
DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS support_staff;
DROP TABLE IF EXISTS ticket_priority;
DROP TABLE IF EXISTS ticket_status;
DROP TABLE IF EXISTS departments;

CREATE TABLE departments (
    department_id INTEGER PRIMARY KEY,
    department_name VARCHAR(50) NOT NULL,
    department_description VARCHAR(200)
);

CREATE TABLE support_staff (
    support_staff_id INTEGER PRIMARY KEY,
    support_staff_fio VARCHAR(100) NOT NULL,
    support_staff_email VARCHAR(100) NOT NULL,
    support_staff_phone VARCHAR(50) NOT NULL
);

CREATE TABLE ticket_priority (
    ticket_priority_id INTEGER PRIMARY KEY,
    ticket_priority_name VARCHAR(50) NOT NULL
);

CREATE TABLE ticket_status (
    ticket_status_id INTEGER PRIMARY KEY,
    ticket_status_name VARCHAR(50) NOT NULL
);

CREATE TABLE users (
    user_id INTEGER PRIMARY KEY,
    user_fio VARCHAR(100) NOT NULL,
    user_phone VARCHAR(50) NOT NULL,
    user_email VARCHAR(100),
    departments_department_id INTEGER,
    FOREIGN KEY (departments_department_id) REFERENCES departments(department_id)
);

CREATE TABLE tickets (
    ticket_id INTEGER PRIMARY KEY,
    ticket_subject VARCHAR(100) NOT NULL,
    ticket_description VARCHAR(100) NOT NULL,
    ticket_data_create DATE NOT NULL,
    users_user_id INTEGER,
    ticket_status_ticket_status_id INTEGER,
    support_staff_support_staff_id INTEGER,
    ticket_priority_id INTEGER,
    FOREIGN KEY (users_user_id) REFERENCES users(user_id),
    FOREIGN KEY (ticket_status_ticket_status_id) REFERENCES ticket_status(ticket_status_id),
    FOREIGN KEY (support_staff_support_staff_id) REFERENCES support_staff(support_staff_id),
    FOREIGN KEY (ticket_priority_id) REFERENCES ticket_priority(ticket_priority_id)
);

CREATE TABLE ticket_comments (
    ticket_comment_id INTEGER PRIMARY KEY,
    ticket_comment_text VARCHAR(1000) NOT NULL,
    ticket_comment_date DATE NOT NULL,
    tickets_ticket_id INTEGER,
    FOREIGN KEY (tickets_ticket_id) REFERENCES tickets(ticket_id)
);

INSERT INTO departments (department_id, department_name, department_description) VALUES 
(1, 'IT отдел', 'Отдел информационных технологий'),
(2, 'Отдел кадров', 'Отдел по работе с персоналом'),
(3, 'Бухгалтерия', 'Финансовый отдел');

-- Приоритеты заявок
INSERT INTO ticket_priority (ticket_priority_id, ticket_priority_name) VALUES 
(1, 'Низкий'),
(2, 'Средний'),
(3, 'Высокий'),
(4, 'Критический');

-- Статусы заявок
INSERT INTO ticket_status (ticket_status_id, ticket_status_name) VALUES 
(1, 'Открыт'),
(2, 'В работе'),
(3, 'Решен'),
(4, 'Закрыт');

-- Сотрудники поддержки (10 человек, включая Петрова С.С.)
INSERT INTO support_staff (support_staff_id, support_staff_fio, support_staff_email, support_staff_phone) VALUES 
(1, 'Петров С.С.', 'petrov.ss@company.com', '+7-900-111-11-11'),
(2, 'Иванова М.П.', 'ivanova.mp@company.com', '+7-900-111-11-12'),
(3, 'Сидоров А.В.', 'sidorov.av@company.com', '+7-900-111-11-13'),
(4, 'Кузнецова О.Д.', 'kuznetsova.od@company.com', '+7-900-111-11-14'),
(5, 'Смирнов Д.Н.', 'smirnov.dn@company.com', '+7-900-111-11-15'),
(6, 'Попова Е.В.', 'popova.ev@company.com', '+7-900-111-11-16'),
(7, 'Васильев А.А.', 'vasiliev.aa@company.com', '+7-900-111-11-17'),
(8, 'Новикова И.Л.', 'novikova.il@company.com', '+7-900-111-11-18'),
(9, 'Федоров П.М.', 'fedorov.pm@company.com', '+7-900-111-11-19'),
(10, 'Морозова Т.С.', 'morozova.ts@company.com', '+7-900-111-11-20');

-- Заполнение users (50 записей)
INSERT INTO users (user_id, user_fio, user_phone, user_email, departments_department_id) VALUES 
(1, 'Иванов А.А.', '+7-900-222-11-11', 'ivanov.aa@company.com', 1),
(2, 'Петрова М.И.', '+7-900-222-11-12', 'petrova.mi@company.com', 2),
(3, 'Сидорова Е.В.', '+7-900-222-11-13', 'sidorova.ev@company.com', 3),
(4, 'Кузнецов Д.В.', '+7-900-222-11-14', 'kuznetsov.dv@company.com', 1),
(5, 'Смирнова О.П.', '+7-900-222-11-15', 'smirnova.op@company.com', 2),
(6, 'Попов В.С.', '+7-900-222-11-16', 'popov.vs@company.com', 3),
(7, 'Васильева А.К.', '+7-900-222-11-17', 'vasilieva.ak@company.com', 1),
(8, 'Новиков И.Л.', '+7-900-222-11-18', 'novikov.il@company.com', 2),
(9, 'Федорова Н.М.', '+7-900-222-11-19', 'fedorova.nm@company.com', 3),
(10, 'Морозов П.Н.', '+7-900-222-11-20', 'morozov.pn@company.com', 1),
(11, 'Волкова С.А.', '+7-900-222-11-21', 'volkova.sa@company.com', 2),
(12, 'Алексеев Н.В.', '+7-900-222-11-22', 'alekseev.nv@company.com', 3),
(13, 'Лебедева К.Д.', '+7-900-222-11-23', 'lebedeva.kd@company.com', 1),
(14, 'Семенов Л.Г.', '+7-900-222-11-24', 'semenov.lg@company.com', 2),
(15, 'Егорова Р.Ф.', '+7-900-222-11-25', 'egorova.rf@company.com', 3),
(16, 'Павлов И.Ц.', '+7-900-222-11-26', 'pavlov.ic@company.com', 1),
(17, 'Козлова А.Ю.', '+7-900-222-11-27', 'kozlova.ayu@company.com', 2),
(18, 'Орлов Т.Б.', '+7-900-222-11-28', 'orlov.tb@company.com', 3),
(19, 'Николаева В.Е.', '+7-900-222-11-29', 'nikolaeva.ve@company.com', 1),
(20, 'Захаров М.Р.', '+7-900-222-11-30', 'zakharov.mr@company.com', 2),
(21, 'Зайцева П.О.', '+7-900-222-11-31', 'zaitseva.po@company.com', 3),
(22, 'Соловьев Е.Т.', '+7-900-222-11-32', 'soloviev.et@company.com', 1),
(23, 'Борисова Г.Я.', '+7-900-222-11-33', 'borisova.gya@company.com', 2),
(24, 'Яковлев А.Ч.', '+7-900-222-11-34', 'yakovlev.ach@company.com', 3),
(25, 'Григорьева М.Ш.', '+7-900-222-11-35', 'grigorieva.msh@company.com', 1),
(26, 'Романов К.Щ.', '+7-900-222-11-36', 'romanov.ksh@company.com', 2),
(27, 'Воробьева Д.Э.', '+7-900-222-11-37', 'vorobieva.de@company.com', 3),
(28, 'Сергеев Л.Ж.', '+7-900-222-11-38', 'sergeev.lzh@company.com', 1),
(29, 'Кузьмина В.З.', '+7-900-222-11-39', 'kuzmina.vz@company.com', 2),
(30, 'Фролов Н.Х.', '+7-900-222-11-40', 'frolov.nh@company.com', 3),
(31, 'Александрова С.В.', '+7-900-222-11-41', 'aleksandrova.sv@company.com', 1),
(32, 'Дмитриев О.Н.', '+7-900-222-11-42', 'dmitriev.on@company.com', 2),
(33, 'Королева И.М.', '+7-900-222-11-43', 'koroleva.im@company.com', 3),
(34, 'Герасимов Т.К.', '+7-900-222-11-44', 'gerasimov.tk@company.com', 1),
(35, 'Тихонова П.Л.', '+7-900-222-11-45', 'tikhonova.pl@company.com', 2),
(36, 'Савченко Е.П.', '+7-900-222-11-46', 'savchenko.ep@company.com', 3),
(37, 'Киселев А.Р.', '+7-900-222-11-47', 'kiselev.ar@company.com', 1),
(38, 'Максимов В.С.', '+7-900-222-11-48', 'maksimov.vs@company.com', 2),
(39, 'Полякова Д.Т.', '+7-900-222-11-49', 'polyakova.dt@company.com', 3),
(40, 'Щербаков И.У.', '+7-900-222-11-50', 'shcherbakov.iu@company.com', 1),
(41, 'Белова М.Ф.', '+7-900-222-11-51', 'belova.mf@company.com', 2),
(42, 'Медведев С.Ц.', '+7-900-222-11-52', 'medvedev.sts@company.com', 3),
(43, 'Антонова К.Ч.', '+7-900-222-11-53', 'antonova.kch@company.com', 1),
(44, 'Марков Л.Ш.', '+7-900-222-11-54', 'markov.lsh@company.com', 2),
(45, 'Львова Р.Щ.', '+7-900-222-11-55', 'lvova.rsh@company.com', 3),
(46, 'Владимиров А.Э.', '+7-900-222-11-56', 'vladimirov.ae@company.com', 1),
(47, 'Соколова Н.Ю.', '+7-900-222-11-57', 'sokolova.nyu@company.com', 2),
(48, 'Панин В.Я.', '+7-900-222-11-58', 'panin.vya@company.com', 3),
(49, 'Жукова Д.В.', '+7-900-222-11-59', 'zhukova.dv@company.com', 1),
(50, 'Никитин Е.С.', '+7-900-222-11-60', 'nikitin.es@company.com', 2);

-- Заполнение tickets (50 записей с несколькими открытыми заявками у Петрова С.С.)
INSERT INTO tickets (ticket_id, ticket_subject, ticket_description, ticket_data_create, users_user_id, ticket_status_ticket_status_id, support_staff_support_staff_id, ticket_priority_id) VALUES 
(1, 'Проблема с принтером', 'Не печатает сетевой принтер в кабинете 301', '2024-01-15', 1, 1, 1, 2),
(2, 'Установка Office', 'Требуется установка Microsoft Office на ПК', '2024-01-16', 2, 1, 1, 2),
(3, 'Доступ к WiFi', 'Нет подключения к корпоративной сети WiFi', '2024-01-17', 3, 1, 1, 3),
(4, 'Зависает компьютер', 'Компьютер тормозит при работе с 1С', '2024-01-18', 4, 2, 2, 2),
(5, 'Настройка Outlook', 'Не работает почтовый клиент Outlook', '2024-01-19', 5, 3, 3, 2),
(6, 'Обновление Windows', 'Требуется обновление ОС до последней версии', '2024-01-20', 6, 1, 1, 2),
(7, 'Проблема с мышкой', 'Не работает USB мышь', '2024-01-21', 7, 1, 1, 1),
(8, 'Установка антивируса', 'Требуется установка антивирусной программы', '2024-01-22', 8, 4, 4, 2),
(9, 'Настройка VPN', 'Не подключается к корпоративному VPN', '2024-01-23', 9, 2, 5, 3),
(10, 'Замена картриджа', 'Требуется замена картриджа в принтере', '2024-01-24', 10, 1, 1, 1),
(11, 'Восстановление файлов', 'Удалены важные документы', '2024-01-25', 11, 3, 6, 4),
(12, 'Проблема с монитором', 'Мерцает экран монитора', '2024-01-26', 12, 1, 1, 2),
(13, 'Настройка сканера', 'Сканер не распознает документы', '2024-01-27', 13, 2, 7, 2),
(14, 'Установка 1С', 'Требуется установка 1С:Предприятие', '2024-01-28', 14, 4, 8, 3),
(15, 'Проблема с интернетом', 'Медленно работает интернет', '2024-01-29', 15, 1, 1, 2),
(16, 'Резервное копирование', 'Настройка автоматического бэкапа', '2024-01-30', 16, 2, 9, 3),
(17, 'Замена клавиатуры', 'Сломалась клавиатура', '2024-02-01', 17, 1, 1, 1),
(18, 'Настройка доступа', 'Нет доступа к общей папке', '2024-02-02', 18, 3, 10, 2),
(19, 'Установка Photoshop', 'Требуется графический редактор', '2024-02-03', 19, 1, 1, 2),
(20, 'Проблема с колонками', 'Не работают колонки', '2024-02-04', 20, 2, 2, 1),
(21, 'Обновление драйверов', 'Требуется обновление драйверов видеокарты', '2024-02-05', 21, 1, 1, 2),
(22, 'Настройка телефона', 'Настройка IP-телефона', '2024-02-06', 22, 4, 3, 2),
(23, 'Проблема с проектором', 'Не включается проектор', '2024-02-07', 23, 1, 1, 3),
(24, 'Восстановление пароля', 'Забыт пароль от учетной записи', '2024-02-08', 24, 3, 4, 2),
(25, 'Установка Python', 'Требуется Python для разработки', '2024-02-09', 25, 1, 1, 2),
(26, 'Проблема с веб-камерой', 'Не работает веб-камера', '2024-02-10', 26, 2, 5, 2),
(27, 'Настройка фаервола', 'Блокируется нужный сайт', '2024-02-11', 27, 1, 1, 3),
(28, 'Установка AutoCAD', 'Требуется система проектирования', '2024-02-12', 28, 4, 6, 3),
(29, 'Проблема с ИБП', 'Не работает источник питания', '2024-02-13', 29, 1, 1, 3),
(30, 'Настройка биометрии', 'Не работает сканер отпечатков', '2024-02-14', 30, 2, 7, 2),
(31, 'Установка Visual Studio', 'Требуется среда разработки', '2024-02-15', 31, 1, 1, 3),
(32, 'Проблема с SSD', 'Медленно работает диск', '2024-02-16', 32, 3, 8, 2),
(33, 'Настройка RAID', 'Настройка RAID-массива', '2024-02-17', 33, 1, 1, 4),
(34, 'Установка Java', 'Требуется Java Runtime', '2024-02-18', 34, 2, 9, 1),
(35, 'Проблема с кулером', 'Сильно шумит кулер', '2024-02-19', 35, 1, 1, 2),
(36, 'Настройка видеоконференции', 'Настройка системы связи', '2024-02-20', 36, 4, 10, 3),
(37, 'Установка Excel', 'Требуется табличный редактор', '2024-02-21', 37, 1, 1, 2),
(38, 'Проблема с наушниками', 'Не работают USB-наушники', '2024-02-22', 38, 2, 2, 1),
(39, 'Настройка почтового клиента', 'Настройка Thunderbird', '2024-02-23', 39, 1, 1, 2),
(40, 'Установка Access', 'Требуется СУБД', '2024-02-24', 40, 3, 3, 2),
(41, 'Проблема с микрофоном', 'Не работает микрофон', '2024-02-25', 41, 1, 1, 2),
(42, 'Настройка роутера', 'Настройка беспроводной сети', '2024-02-26', 42, 2, 4, 3),
(43, 'Установка браузера', 'Требуется Chrome', '2024-02-27', 43, 1, 1, 1),
(44, 'Проблема с тачпадом', 'Не работает тачпад', '2024-02-28', 44, 3, 5, 2),
(45, 'Настройка принтера', 'Добавление сетевого принтера', '2024-02-29', 45, 1, 1, 1),
(46, 'Установка PowerPoint', 'Требуется для презентаций', '2024-03-01', 46, 2, 6, 2),
(47, 'Проблема с блоком питания', 'Не включается ПК', '2024-03-02', 47, 1, 1, 4),
(48, 'Настройка монитора', 'Неправильное разрешение', '2024-03-03', 48, 3, 7, 1),
(49, 'Установка Word', 'Требуется текстовый редактор', '2024-03-04', 49, 1, 1, 2),
(50, 'Проблема с сетевой картой', 'Нет сетевого подключения', '2024-03-05', 50, 2, 8, 3);

-- Заполнение ticket_comments (50 записей)
INSERT INTO ticket_comments (ticket_comment_id, ticket_comment_text, ticket_comment_date, tickets_ticket_id) VALUES 
(1, 'Проверил принтер, проблема в картридже', '2024-01-15', 1),
(2, 'Установил Office 365, проверил работу', '2024-01-16', 2),
(3, 'Сбросил настройки WiFi, доступ восстановлен', '2024-01-17', 3),
(4, 'Произвел очистку системы от временных файлов', '2024-01-18', 4),
(5, 'Настроил почтовый клиент, проблема решена', '2024-01-19', 5),
(6, 'Запустил обновление Windows', '2024-01-20', 6),
(7, 'Заменил USB мышь на новую', '2024-01-21', 7),
(8, 'Установил антивирус Касперского', '2024-01-22', 8),
(9, 'Настроил VPN подключение', '2024-01-23', 9),
(10, 'Заменил картридж в принтере HP', '2024-01-24', 10),
(11, 'Восстановил файлы из резервной копии', '2024-01-25', 11),
(12, 'Подключил запасной монитор', '2024-01-26', 12),
(13, 'Настроил драйвер сканера', '2024-01-27', 13),
(14, 'Установил 1С:Предприятие 8.3', '2024-01-28', 14),
(15, 'Проверил скорость интернета, проблема у провайдера', '2024-01-29', 15),
(16, 'Настроил ежедневное резервное копирование', '2024-01-30', 16),
(17, 'Заменил клавиатуру на механическую', '2024-02-01', 17),
(18, 'Настроил права доступа к папке', '2024-02-02', 18),
(19, 'Установил Adobe Photoshop CC', '2024-02-03', 19),
(20, 'Проверил подключение колонок, работает', '2024-02-04', 20),
(21, 'Обновил драйверы NVIDIA', '2024-02-05', 21),
(22, 'Настроил IP-телефон Yealink', '2024-02-06', 22),
(23, 'Заменил лампу в проекторе', '2024-02-07', 23),
(24, 'Сбросил пароль, выдал временный', '2024-02-08', 24),
(25, 'Установил Python 3.9 с окружением', '2024-02-09', 25),
(26, 'Настроил драйвер веб-камеры', '2024-02-10', 26),
(27, 'Добавил сайт в исключения фаервола', '2024-02-11', 27),
(28, 'Установил AutoCAD 2024', '2024-02-12', 28),
(29, 'Заменил батарею в ИБП', '2024-02-13', 29),
(30, 'Настроил сканер отпечатков пальцев', '2024-02-14', 30),
(31, 'Установил Visual Studio 2022', '2024-02-15', 31),
(32, 'Произвел оптимизацию SSD', '2024-02-16', 32),
(33, 'Настроил RAID 1 массив', '2024-02-17', 33),
(34, 'Установил Java Runtime Environment', '2024-02-18', 34),
(35, 'Почистил кулер от пыли', '2024-02-19', 35),
(36, 'Настроил систему видеоконференцсвязи', '2024-02-20', 36),
(37, 'Установил Microsoft Excel', '2024-02-21', 37),
(38, 'Проверил наушники, заменил на новые', '2024-02-22', 38),
(39, 'Настроил почтовый клиент Thunderbird', '2024-02-23', 39),
(40, 'Установил Microsoft Access', '2024-02-24', 40),
(41, 'Настроил чувствительность микрофона', '2024-02-25', 41),
(42, 'Настроил беспроводной роутер', '2024-02-26', 42),
(43, 'Установил Google Chrome', '2024-02-27', 43),
(44, 'Обновил драйвер тачпада', '2024-02-28', 44),
(45, 'Добавил сетевой принтер в систему', '2024-02-29', 45),
(46, 'Установил Microsoft PowerPoint', '2024-03-01', 46),
(47, 'Заменил блок питания на 600W', '2024-03-02', 47),
(48, 'Настроил разрешение 1920x1080', '2024-03-03', 48),
(49, 'Установил Microsoft Word', '2024-03-04', 49),
(50, 'Заменил сетевую карту', '2024-03-05', 50);

SELECT 
     tickets.ticket_id as "Номер заявки",
     tickets.ticket_status_ticket_status_id as "Статус заявки"
     FROM tickets
     INNER JOIN support_staff ON tickets.support_staff_support_staff_id = support_staff.support_staff_id
     INNER JOIN ticket_status ON tickets.ticket_status_ticket_status_id = ticket_status.ticket_status_id
   WHERE support_staff.support_staff_fio = 'Петров С.С'
   AND ticket_status.ticket_status_name = 'Открыт';

SELECT support_staff_id, support_staff_fio 
FROM support_staff 
WHERE support_staff_fio LIKE '%Петров%';

SELECT 
    t.ticket_id,
    t.ticket_subject,
    ss.support_staff_fio,
    ts.ticket_status_name
    FROM tickets t
    INNER JOIN support_staff ss ON t.support_staff_support_staff_id = ss.support_staff_id
    INNER JOIN ticket_status ts ON t.ticket_status_ticket_status_id = ts.ticket_status_id
    WHERE ss.support_staff_fio LIKE '%Петров%';

SELECT 
       tickets.ticket_id as "Номер заявки",
       tickets.ticket_subject as "Имя заявки",
       tickets.ticket_description as "Описание заявки"
     FROM tickets
     INNER JOIN ticket_status ON tickets.ticket_status_ticket_status_id = ticket_status.ticket_status_id
     INNER JOIN support_staff ON tickets.support_staff_support_staff_id = support_staff.support_staff_id
     WHERE ticket_status.ticket_status_name = 'Открыт'
     AND support_staff.support_staff_fio = 'Петров С.С.';
     
 SELECT 
     support_staff.support_staff_fio as "ФИО сотрудника",
     COUNT(tickets.ticket_id) as "Количество решённых заявок"
     FROM tickets
     INNER JOIN ticket_status ON tickets.ticket_status_ticket_status_id = ticket_status.ticket_status_id
     INNER JOIN support_staff ON tickets.support_staff_support_staff_id = support_staff.support_staff_id
     WHERE ticket_status.ticket_status_name = 'Решен'
     GROUP BY support_staff.support_staff_fio