import random
from google.colab import files

# --- Настройки ---
DB_NAME_PLACEHOLDER = "mgpu_ico_db_20"
OUTPUT_SQL_FILENAME = "populate_employees_tickets.sql"

# --- Данные для генерации ---
employees_data = [
    ('Иванов Иван Иванович', 'IT'),
    ('Петрова Анна Сергеевна', 'HR'),
    ('Сидоров Алексей Петрович', 'Финансы'),
    ('Козлова Мария Владимировна', 'IT')
]

tickets_data = [
    ('user001', 'Не работает принтер в кабинете 301', 'Открыта'),
    ('user045', 'Сбой в работе почтового клиента', 'Закрыта'),
    ('user078', 'Запросить доступ к сетевой папке', 'Открыта'),
    ('user123', 'Обновить программное обеспечение', 'В работе')
]

# --- Функции для генерации SQL-запросов ---

def generate_create_tables():
    """Генерирует CREATE TABLE запросы."""
    create_scripts = []
    
    create_scripts.append("CREATE TABLE employees (")
    create_scripts.append("  employee_id INT NOT NULL AUTO_INCREMENT,")
    create_scripts.append("  full_name VARCHAR(255) NOT NULL,")
    create_scripts.append("  department VARCHAR(255) NOT NULL,")
    create_scripts.append("  PRIMARY KEY (employee_id)")
    create_scripts.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")
    
    create_scripts.append("\n-- Создание таблицы tickets")
    create_scripts.append("CREATE TABLE tickets (")
    create_scripts.append("  ticket_id INT NOT NULL AUTO_INCREMENT,")
    create_scripts.append("  user_name VARCHAR(255) NOT NULL,")
    create_scripts.append("  description VARCHAR(255) NOT NULL,")
    create_scripts.append("  status VARCHAR(50) NOT NULL,")
    create_scripts.append("  PRIMARY KEY (ticket_id)")
    create_scripts.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")
    
    return "\n".join(create_scripts)

def generate_employees_insert_statements():
    """Генерирует INSERT запросы для таблицы employees."""
    inserts = []
    inserts.append("-- Заполнение таблицы 'employees'")
    for employee in employees_data:
        full_name, department = employee
        inserts.append(
            f"INSERT INTO employees (full_name, department) VALUES ('{full_name}', '{department}');"
        )
    return "\n".join(inserts)

def generate_tickets_insert_statements():
    """Генерирует INSERT запросы для таблицы tickets."""
    inserts = []
    inserts.append("\n-- Заполнение таблицы 'tickets'")
    for ticket in tickets_data:
        user_name, description, status = ticket
        inserts.append(
            f"INSERT INTO tickets (user_name, description, status) VALUES ('{user_name}', '{description}', '{status}');"
        )
    return "\n".join(inserts)

def generate_select_queries():
    """Генерирует SELECT запросы."""
    selects = []
    selects.append("-- Вывести все заявки со статусом \"Открыта\"")
    selects.append("SELECT * ")
    selects.append("FROM tickets ")
    selects.append("WHERE status = 'Открыта';")
    
    selects.append("\nSELECT * FROM employees;")
    
    selects.append("\nSELECT * FROM tickets;")
    
    return "\n".join(selects)

# --- Основная логика скрипта ---
sql_script_content = []
sql_script_content.append(f"USE {DB_NAME_PLACEHOLDER};")
sql_script_content.append(generate_create_tables())
sql_script_content.append("\n")
sql_script_content.append(generate_employees_insert_statements())
sql_script_content.append(generate_tickets_insert_statements())
sql_script_content.append("\n")
sql_script_content.append(generate_select_queries())

final_sql_string = "\n".join(sql_script_content)

# Создание и скачивание файла
with open(OUTPUT_SQL_FILENAME, "w", encoding="utf-8") as f:
    f.write(final_sql_string)

print(f"SQL-скрипт '{OUTPUT_SQL_FILENAME}' успешно сгенерирован.")
print("Сейчас начнется скачивание файла...")

files.download(OUTPUT_SQL_FILENAME)